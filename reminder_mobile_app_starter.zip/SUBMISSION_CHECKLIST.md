# Submission Checklist (28 tasks)

Use your public GitHub repository URL for Task 1. Use direct GitHub file URLs for the source-code links.

| Task | Deliverable | What to link/capture |
|---:|---|---|
| 1 | Public GitHub repository | Repository URL; set visibility to Public |
| 2 | User stories | `user-stories.md` (all 9 stories) |
| 3 | Figma evidence 1 | `figma-evidence1.png` or `.jpg`: login, registration, home, detail, favorites/profile |
| 4 | Figma evidence 2 | `figma-evidence2.png` or `.jpg`: API, settings menu, settings, notifications |
| 5 | Signup code | `App.js` — `SignupScreen` |
| 6 | Signup screen | `signup_screen_evidence.png` |
| 7 | Signup error | `signup_error.png` |
| 8 | Login code | `App.js` — `LoginScreen` |
| 9 | Login screen | `login_screen_evidence.png` |
| 10 | Login error | `login_error.png` |
| 11 | Home code | `App.js` — `HomeScreen` |
| 12 | Home screen | `home-screen-evidence.png` |
| 13 | Detail code | `App.js` — `DetailScreen` |
| 14 | Navigation icon | `evidence-detail-navigation.png` |
| 15 | Detail screen | `evidence-detail-screen.png` |
| 16 | Local storage code | `App.js` — AsyncStorage calls and `STORAGE_KEYS` |
| 17 | Persistence evidence | `evidence-persistence.png`; show saved data using an appropriate debugger/storage inspector |
| 18 | UI + storage evidence | `evidence-integrateScreen-persistence.png` |
| 19 | API code | `App.js` — `HomeScreen` fetch call |
| 20 | API evidence | `evidence-api-ux.png` |
| 21 | Settings menu code | `App.js` — `SettingsScreen` |
| 22 | Menu icon | `evidence-menu-icon.jpg` or `.png` |
| 23 | Menu items | `evidence-menu-items.jpg` or `.png` |
| 24 | Settings screen code | `App.js` — `SettingsScreen` |
| 25 | Settings screen | `evidence-settings-screen.png` |
| 26 | Notification code | `App.js` — `NotificationsScreen` and `expo-notifications` setup |
| 27 | Notification configuration | `evidence-notification-configure.png` |
| 28 | Triggered notification | `evidence-notification-alert.png` |

## Screenshot rules
- Use the exact required filenames.
- Capture actual running application screens and actual Figma screens.
- For error screenshots, trigger the relevant validation error and capture it.
- For notification evidence, capture the setup and a real triggered notification.
- Do not use mockups as proof that functionality works.
