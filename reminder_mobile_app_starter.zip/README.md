# Reminder Mobile App — Final Project Starter

A React Native + Expo demonstration app covering signup, login, home, detail, favorites, AsyncStorage persistence, external API integration, settings, and local notifications.

## Requirements
- Node.js LTS
- Expo Go or an Android/iOS emulator
- Internet access for the JSONPlaceholder API

## Run the project
1. Extract this folder.
2. Open a terminal in the project folder.
3. Run `npm install`.
4. Run `npx expo install --fix` to align installed package versions with the Expo SDK.
5. Run `npx expo start`.
6. Scan the QR code with Expo Go or open the project in a compatible emulator.

## Test flow
1. Open the app and choose **Sign up**.
2. Create a demo account using a valid email and a password of at least 6 characters.
3. On Home, open an API post to view its detail screen; save one as a favorite.
4. Open Settings and change the notification preferences.
5. Open Notifications, leave the delay at `10` seconds, and tap **Schedule local notification**.
6. Grant notification permission when prompted. Keep the app/device available and verify the alert appears.
7. For a quick test, tap **Send test notification now**.
8. Reopen the app and verify the favorites and scheduled-reminder records remain saved.

## Important limitations
- This is a learning/demo implementation. Signup credentials are stored locally and are **not secure production authentication**. Do not use a real password. A production app should use a secure backend and never store plaintext passwords.
- A local notification can be scheduled by the operating system and may fire while the app is backgrounded or closed, subject to OS permissions, device settings, battery restrictions, and platform behavior.
- This starter uses a delay field rather than a calendar date/time picker. Replace it with a native date/time picker if your evaluator requires selecting a calendar date and clock time.
- Figma evidence screenshots must be captured from your own Figma designs. App evidence screenshots must be captured from a real running app/device/emulator. Do not submit fabricated screenshots.
- Before a public release, configure real app identifiers, review current store policies, and replace demo authentication with secure authentication.

## Suggested evidence checklist
See `SUBMISSION_CHECKLIST.md` for the expected screenshot names and GitHub links.

## User stories
See [`user-stories.md`](./user-stories.md).
