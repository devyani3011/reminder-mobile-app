import React, { useEffect, useState } from "react";
import {
  ActivityIndicator, Alert, Button, FlatList, Platform, Pressable,
  SafeAreaView, ScrollView, StyleSheet, Switch, Text, TextInput, View
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Notifications from "expo-notifications";
import { StatusBar } from "expo-status-bar";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

const Stack = createNativeStackNavigator();
const STORAGE_KEYS = {
  user: "@reminder_demo_user",
  preferences: "@reminder_demo_preferences",
  favorites: "@reminder_demo_favorites",
  reminders: "@reminder_demo_reminders"
};

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true
  })
});

const theme = {
  bg: "#F5F7FB", card: "#FFFFFF", ink: "#172033",
  muted: "#687386", accent: "#3659D9", border: "#DDE3EE",
  danger: "#B42318", success: "#137547"
};

function Page({ children }) {
  return <SafeAreaView style={styles.safe}><ScrollView contentContainerStyle={styles.page}>{children}</ScrollView></SafeAreaView>;
}
function Heading({ children }) { return <Text style={styles.heading}>{children}</Text>; }
function Field({ label, ...props }) {
  return <View style={styles.field}><Text style={styles.label}>{label}</Text><TextInput
    style={styles.input} placeholderTextColor="#929BAA" autoCapitalize="none" {...props}
  /></View>;
}
function PrimaryButton({ title, onPress }) {
  return <Pressable onPress={onPress} style={styles.primaryButton}><Text style={styles.primaryButtonText}>{title}</Text></Pressable>;
}
function LinkButton({ title, onPress }) {
  return <Pressable onPress={onPress} style={styles.linkButton}><Text style={styles.linkText}>{title}</Text></Pressable>;
}
function ErrorText({ children }) {
  if (!children) return null;
  return <Text accessibilityRole="alert" style={styles.error}>{children}</Text>;
}

function LoginScreen({ navigation, onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  async function submit() {
    setError("");
    if (!email.trim() || !password) return setError("Enter your email and password.");
    const saved = await AsyncStorage.getItem(STORAGE_KEYS.user);
    if (!saved) return setError("No account found. Please sign up first.");
    const user = JSON.parse(saved);
    if (user.email.toLowerCase() !== email.trim().toLowerCase() || user.password !== password) {
      return setError("Incorrect email or password. Please try again.");
    }
    onLogin(user);
  }
  return <Page>
    <View style={styles.brand}><Text style={styles.logo}>◷</Text><Text style={styles.brandTitle}>Reminder</Text><Text style={styles.muted}>Make time for what matters.</Text></View>
    <Heading>Welcome back</Heading>
    <Text style={styles.muted}>Log in to manage your reminders.</Text>
    <Field label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" placeholder="you@example.com" />
    <Field label="Password" value={password} onChangeText={setPassword} placeholder="Enter password" secureTextEntry />
    <ErrorText>{error}</ErrorText>
    <PrimaryButton title="Log in" onPress={submit} />
    <View style={styles.inline}><Text style={styles.muted}>Don't have an account? </Text><LinkButton title="Sign up" onPress={() => navigation.navigate("Signup")} /></View>
  </Page>;
}

function SignupScreen({ navigation, onLogin }) {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  async function submit() {
    setError("");
    if (!username.trim() || !email.trim() || !password) return setError("Please complete all three fields.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return setError("Enter a valid email address.");
    if (password.length < 6) return setError("Password must be at least 6 characters.");
    const user = { username: username.trim(), email: email.trim(), password };
    await AsyncStorage.setItem(STORAGE_KEYS.user, JSON.stringify(user));
    onLogin(user);
  }
  return <Page>
    <View style={styles.brand}><Text style={styles.logo}>◷</Text><Text style={styles.brandTitle}>Create account</Text><Text style={styles.muted}>Start planning your time.</Text></View>
    <Field label="Username" value={username} onChangeText={setUsername} placeholder="Your name" />
    <Field label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" placeholder="you@example.com" />
    <Field label="Password" value={password} onChangeText={setPassword} placeholder="At least 6 characters" secureTextEntry />
    <ErrorText>{error}</ErrorText>
    <PrimaryButton title="Sign up" onPress={submit} />
    <View style={styles.inline}><Text style={styles.muted}>Already registered? </Text><LinkButton title="Log in" onPress={() => navigation.navigate("Login")} /></View>
  </Page>;
}

function HomeScreen({ navigation, user, reminders, favorites, setFavorites }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState("");
  useEffect(() => {
    let active = true;
    fetch("https://jsonplaceholder.typicode.com/posts?_limit=8")
      .then(r => { if (!r.ok) throw new Error("Could not fetch data."); return r.json(); })
      .then(data => { if (active) { setItems(data); setApiError(""); } })
      .catch(() => { if (active) setApiError("Could not load API data. Check your internet connection and try again."); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);
  function toggleFavorite(id) {
    const next = favorites.includes(id) ? favorites.filter(x => x !== id) : [...favorites, id];
    setFavorites(next);
    AsyncStorage.setItem(STORAGE_KEYS.favorites, JSON.stringify(next));
  }
  return <Page>
    <View style={styles.headerRow}><View><Text style={styles.muted}>Hello, {user?.username || "there"}</Text><Heading>Discover</Heading></View><Text style={styles.logoSmall}>◷</Text></View>
    <View style={styles.summary}><Text style={styles.summaryNumber}>{reminders.length}</Text><View style={{flex:1}}><Text style={styles.summaryTitle}>Scheduled reminders</Text><Text style={styles.muted}>Saved on this device</Text></View><PrimaryButton title="Settings" onPress={() => navigation.navigate("Settings")} /></View>
    <Heading>Explore from API</Heading>
    <Text style={styles.muted}>Sample posts fetched from JSONPlaceholder.</Text>
    {loading ? <ActivityIndicator style={{margin:20}} /> : null}
    <ErrorText>{apiError}</ErrorText>
    {items.map(item => <View key={item.id} style={styles.card}>
      <Pressable onPress={() => navigation.navigate("Detail", { item })}>
        <Text style={styles.cardTitle}>{item.title}</Text>
        <Text style={styles.body} numberOfLines={2}>{item.body}</Text>
        <Text style={styles.linkText}>View details →</Text>
      </Pressable>
      <Pressable style={styles.favoriteButton} onPress={() => toggleFavorite(item.id)}>
        <Text style={{color: favorites.includes(item.id) ? theme.accent : theme.muted}}>{favorites.includes(item.id) ? "★ Saved" : "☆ Save"}</Text>
      </Pressable>
    </View>)}
    <PrimaryButton title="My Favorites" onPress={() => navigation.navigate("Favorites")} />
    <PrimaryButton title="Schedule a reminder" onPress={() => navigation.navigate("Notifications")} />
  </Page>;
}

function DetailScreen({ route }) {
  const { item } = route.params;
  return <Page>
    <Text style={styles.kicker}>DETAILS · ITEM {item.id}</Text>
    <Heading>{item.title}</Heading>
    <Text style={styles.bodyLarge}>{item.body}</Text>
    <View style={styles.card}><Text style={styles.label}>Source</Text><Text style={styles.body}>JSONPlaceholder external API</Text><Text style={styles.label}>Post ID</Text><Text style={styles.body}>{item.id}</Text><Text style={styles.label}>User ID</Text><Text style={styles.body}>{item.userId}</Text></View>
  </Page>;
}

function FavoritesScreen({ favorites }) {
  return <Page><Heading>Favorites</Heading><Text style={styles.muted}>Saved post IDs are stored locally on this device.</Text>
    {favorites.length ? favorites.map(id => <View key={id} style={styles.card}><Text style={styles.cardTitle}>Saved post #{id}</Text></View>) : <Text style={styles.empty}>No favorites yet. Save an item from the home screen.</Text>}
  </Page>;
}

function SettingsScreen({ navigation, user, onLogout, preferences, setPreferences }) {
  const [menuOpen, setMenuOpen] = useState(true);
  async function update(key, value) {
    const next = { ...preferences, [key]: value };
    setPreferences(next);
    await AsyncStorage.setItem(STORAGE_KEYS.preferences, JSON.stringify(next));
  }
  return <Page>
    <Heading>Settings</Heading>
    <Text style={styles.muted}>Manage your app preferences.</Text>
    <Pressable style={styles.menuHeader} onPress={() => setMenuOpen(!menuOpen)}><Text style={styles.cardTitle}>☰  Settings menu</Text><Text>{menuOpen ? "−" : "+"}</Text></Pressable>
    {menuOpen && <View style={styles.menuItems}>
      <Pressable onPress={() => navigation.navigate("Notifications")} style={styles.menuItem}><Text style={styles.body}>🔔  Notifications</Text><Text style={styles.muted}>Schedule a local reminder</Text></Pressable>
      <Pressable onPress={() => navigation.navigate("Favorites")} style={styles.menuItem}><Text style={styles.body}>☆  Favorites</Text><Text style={styles.muted}>View saved items</Text></Pressable>
      <View style={styles.menuItem}><Text style={styles.body}>👤  Account</Text><Text style={styles.muted}>{user?.email || "No account"}</Text></View>
    </View>}
    <View style={styles.settingRow}><View style={{flex:1}}><Text style={styles.cardTitle}>Notifications enabled</Text><Text style={styles.muted}>Allow reminder scheduling in the app</Text></View><Switch value={preferences.enabled} onValueChange={v => update("enabled", v)} /></View>
    <View style={styles.settingRow}><View style={{flex:1}}><Text style={styles.cardTitle}>Sound preference</Text><Text style={styles.muted}>Play a sound with reminders</Text></View><Switch value={preferences.sound} onValueChange={v => update("sound", v)} /></View>
    <PrimaryButton title="Notification settings" onPress={() => navigation.navigate("Notifications")} />
    <PrimaryButton title="Log out" onPress={onLogout} />
  </Page>;
}

function NotificationsScreen({ reminders, setReminders, preferences }) {
  const [title, setTitle] = useState("Reminder");
  const [message, setMessage] = useState("It's time to do your planned task.");
  const [seconds, setSeconds] = useState("10");
  const [status, setStatus] = useState("");
  async function schedule() {
    setStatus("");
    if (!preferences.enabled) return setStatus("Notifications are switched off in Settings.");
    const delay = Number(seconds);
    if (!Number.isFinite(delay) || delay < 3 || delay > 86400) return setStatus("Enter a delay from 3 to 86400 seconds.");
    const permission = await Notifications.requestPermissionsAsync();
    if (!permission.granted) return setStatus("Permission was not granted. Enable notifications in device settings.");
    if (Platform.OS === "android") {
      await Notifications.setNotificationChannelAsync("reminders", {
        name: "Reminders",
        importance: Notifications.AndroidImportance.HIGH,
        vibrationPattern: [0, 250, 250, 250],
        sound: preferences.sound ? "default" : null
      });
    }
    const triggerDate = new Date(Date.now() + delay * 1000);
    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title: title.trim() || "Reminder",
        body: message.trim() || "Your scheduled reminder is due.",
        sound: preferences.sound ? "default" : undefined,
        data: { type: "local-reminder" }
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: triggerDate,
        ...(Platform.OS === "android" ? { channelId: "reminders" } : {})
      }
    });
    const record = { id, title: title.trim() || "Reminder", message: message.trim(), scheduledAt: triggerDate.toISOString(), delaySeconds: delay };
    const next = [record, ...reminders];
    setReminders(next);
    await AsyncStorage.setItem(STORAGE_KEYS.reminders, JSON.stringify(next));
    setStatus(`Scheduled successfully for ${triggerDate.toLocaleString()}. Keep notifications enabled on your device.`);
  }
  async function cancel(id) {
    await Notifications.cancelScheduledNotificationAsync(id);
    const next = reminders.filter(r => r.id !== id);
    setReminders(next);
    await AsyncStorage.setItem(STORAGE_KEYS.reminders, JSON.stringify(next));
    setStatus("Reminder cancelled.");
  }
  async function testNow() {
    const permission = await Notifications.requestPermissionsAsync();
    if (!permission.granted) return setStatus("Notification permission is required.");
    await Notifications.scheduleNotificationAsync({
      content: { title: "Test notification", body: "Your local notification test worked!", sound: preferences.sound ? "default" : undefined },
      trigger: null
    });
    setStatus("A test notification was sent immediately. Check the device notification area.");
  }
  return <Page>
    <Heading>Notifications</Heading>
    <Text style={styles.muted}>Schedule a local notification on this device. For a quick test, use 10 seconds.</Text>
    <Field label="Notification title" value={title} onChangeText={setTitle} placeholder="Reminder" />
    <Field label="Message" value={message} onChangeText={setMessage} placeholder="What should you remember?" />
    <Field label="Trigger after (seconds; minimum 3)" value={seconds} onChangeText={setSeconds} keyboardType="numeric" placeholder="10" />
    <PrimaryButton title="Schedule local notification" onPress={schedule} />
    <PrimaryButton title="Send test notification now" onPress={testNow} />
    {!!status && <View style={styles.notice}><Text style={styles.body}>{status}</Text></View>}
    <Heading>Scheduled reminders</Heading>
    {reminders.length === 0 ? <Text style={styles.empty}>No scheduled reminders yet.</Text> : reminders.map(r => <View key={r.id} style={styles.card}>
      <Text style={styles.cardTitle}>{r.title}</Text><Text style={styles.body}>{r.message}</Text>
      <Text style={styles.muted}>Scheduled: {new Date(r.scheduledAt).toLocaleString()}</Text>
      <LinkButton title="Cancel reminder" onPress={() => cancel(r.id)} />
    </View>)}
  </Page>;
}

function AppNavigator() {
  const [user, setUser] = useState(null);
  const [reminders, setReminders] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [preferences, setPreferences] = useState({ enabled: true, sound: true });
  const [ready, setReady] = useState(false);
  useEffect(() => {
    (async () => {
      try {
        const [savedUser, savedReminders, savedFavorites, savedPreferences] = await Promise.all([
          AsyncStorage.getItem(STORAGE_KEYS.user),
          AsyncStorage.getItem(STORAGE_KEYS.reminders),
          AsyncStorage.getItem(STORAGE_KEYS.favorites),
          AsyncStorage.getItem(STORAGE_KEYS.preferences)
        ]);
        if (savedUser) setUser(JSON.parse(savedUser));
        if (savedReminders) setReminders(JSON.parse(savedReminders));
        if (savedFavorites) setFavorites(JSON.parse(savedFavorites));
        if (savedPreferences) setPreferences(JSON.parse(savedPreferences));
      } catch (e) {
        console.warn("Could not restore saved app data", e);
      } finally { setReady(true); }
    })();
  }, []);
  async function logout() { setUser(null); }
  if (!ready) return <SafeAreaView style={styles.safe}><ActivityIndicator style={{marginTop:60}} /></SafeAreaView>;
  return <NavigationContainer>
    <Stack.Navigator screenOptions={{headerStyle:{backgroundColor:theme.card}, headerTintColor:theme.ink, headerTitleStyle:{fontWeight:"700"}, contentStyle:{backgroundColor:theme.bg}}}>
      {!user ? <>
        <Stack.Screen name="Login" options={{title:"Reminder"}}>{props => <LoginScreen {...props} onLogin={setUser} />}</Stack.Screen>
        <Stack.Screen name="Signup" options={{title:"Create account"}}>{props => <SignupScreen {...props} onLogin={setUser} />}</Stack.Screen>
      </> : <>
        <Stack.Screen name="Home" options={{title:"Reminder", headerBackVisible:false}}>{props => <HomeScreen {...props} user={user} reminders={reminders} favorites={favorites} setFavorites={setFavorites} />}</Stack.Screen>
        <Stack.Screen name="Detail" component={DetailScreen} options={{title:"Details"}} />
        <Stack.Screen name="Favorites" options={{title:"Favorites"}}>{props => <FavoritesScreen {...props} favorites={favorites} />}</Stack.Screen>
        <Stack.Screen name="Settings" options={{title:"Settings"}}>{props => <SettingsScreen {...props} user={user} onLogout={logout} preferences={preferences} setPreferences={setPreferences} />}</Stack.Screen>
        <Stack.Screen name="Notifications" options={{title:"Notifications"}}>{props => <NotificationsScreen {...props} reminders={reminders} setReminders={setReminders} preferences={preferences} />}</Stack.Screen>
      </>}
    </Stack.Navigator>
    <StatusBar style="dark" />
  </NavigationContainer>;
}

export default function App() { return <AppNavigator />; }

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:theme.bg},
  page:{padding:20,paddingBottom:36,gap:14},
  brand:{alignItems:"center",paddingVertical:22,gap:5},
  logo:{fontSize:48,color:theme.accent,fontWeight:"800"},
  logoSmall:{fontSize:34,color:theme.accent,fontWeight:"800"},
  brandTitle:{fontSize:26,fontWeight:"800",color:theme.ink},
  heading:{fontSize:24,fontWeight:"800",color:theme.ink,marginTop:4},
  muted:{fontSize:14,color:theme.muted,lineHeight:20},
  field:{gap:7,marginTop:5},
  label:{fontSize:14,fontWeight:"700",color:theme.ink},
  input:{borderWidth:1,borderColor:theme.border,backgroundColor:theme.card,borderRadius:12,paddingHorizontal:14,paddingVertical:13,fontSize:16,color:theme.ink},
  primaryButton:{backgroundColor:theme.accent,paddingHorizontal:16,paddingVertical:14,borderRadius:12,alignItems:"center",marginTop:4},
  primaryButtonText:{color:"#FFFFFF",fontSize:15,fontWeight:"700"},
  linkButton:{paddingVertical:5,alignSelf:"flex-start"},
  linkText:{color:theme.accent,fontWeight:"700"},
  inline:{flexDirection:"row",alignItems:"center",justifyContent:"center",flexWrap:"wrap",marginTop:4},
  error:{color:theme.danger,fontSize:14,lineHeight:20,marginTop:3},
  headerRow:{flexDirection:"row",justifyContent:"space-between",alignItems:"center"},
  summary:{backgroundColor:"#E8EDFF",borderRadius:16,padding:14,flexDirection:"row",alignItems:"center",gap:10,flexWrap:"wrap"},
  summaryNumber:{fontSize:30,fontWeight:"800",color:theme.accent},
  summaryTitle:{fontSize:15,fontWeight:"700",color:theme.ink},
  card:{backgroundColor:theme.card,borderWidth:1,borderColor:theme.border,borderRadius:14,padding:15,gap:9},
  cardTitle:{fontSize:16,fontWeight:"700",color:theme.ink,lineHeight:23},
  body:{fontSize:14,color:theme.muted,lineHeight:21},
  bodyLarge:{fontSize:17,color:theme.ink,lineHeight:28},
  favoriteButton:{alignSelf:"flex-start",paddingTop:4},
  kicker:{fontSize:12,fontWeight:"800",letterSpacing:1,color:theme.accent},
  empty:{padding:18,color:theme.muted,backgroundColor:theme.card,borderRadius:12,lineHeight:22},
  menuHeader:{backgroundColor:theme.card,borderWidth:1,borderColor:theme.border,borderRadius:12,padding:15,flexDirection:"row",justifyContent:"space-between"},
  menuItems:{backgroundColor:theme.card,borderRadius:12,borderWidth:1,borderColor:theme.border,paddingHorizontal:14},
  menuItem:{paddingVertical:13,borderBottomWidth:1,borderBottomColor:theme.border,gap:4},
  settingRow:{backgroundColor:theme.card,borderWidth:1,borderColor:theme.border,borderRadius:12,padding:14,flexDirection:"row",alignItems:"center",gap:12},
  notice:{backgroundColor:"#E6F6EC",borderColor:"#B5E2C4",borderWidth:1,borderRadius:12,padding:13}
});
