# User Stories — Reminder Mobile App

1. **Account registration:** As a new user, I want to create an account with a username, email, and password so that I can access the app.
2. **Login:** As a registered user, I want to log in with my email and password so that I can access my reminders.
3. **Home screen:** As a user, I want a home screen with clear navigation and an app logo so that I can find the app's main features.
4. **Item details:** As a user, I want to open an item and view its details so that I can understand the information before saving it.
5. **Favorites:** As a user, I want to save and view favorite items so that I can find them again later.
6. **Local persistence:** As a user, I want my preferences, favorites, and reminder records to remain saved locally so that they are available after I reopen the app.
7. **External API:** As a user, I want the app to fetch and display information from an external API so that the content is not limited to hard-coded examples.
8. **Settings:** As a user, I want a settings menu with notification preferences so that I can control how the app behaves.
9. **Scheduled notifications:** As a user, I want to schedule a local reminder and receive a notification at the selected time so that I do not forget an important task.
